% Definir valores de amplitude para testar
sine_amplitudes = [20, 80, 140, 200];
num_values = length(sine_amplitudes);

mse_pid2 = zeros(1, num_values);
mse_fuzzy2 = zeros(1, num_values);

for i = 1:num_values
    set_param('MSE_Sim_Sine/Sine Wave4', 'Amplitude', num2str(sine_amplitudes(i)));
    
    simOut = sim('MSE_Sim_Sine');
    
    % Extrair os resultados do MSE da simulação e calcular o erro quadrático médio
    mse_pid2_data = simOut.get('mse_pid2');
    mse_fuzzy2_data = simOut.get('mse_fuzzy2');
    
    % Debug
    disp('mse_pid2_data:');
    disp(mse_pid2_data);
    disp('mse_fuzzy2_data:');
    disp(mse_fuzzy2_data);
    
    % Retirar valores NaN
    mse_pid2_data = mse_pid2_data(~isnan(mse_pid2_data));
    mse_fuzzy2_data = mse_fuzzy2_data(~isnan(mse_fuzzy2_data));
    
    % Calcular o erro quadrático médio para PID e Fuzzy
    mse_pid2(i) = mean(mse_pid2_data.^2);   
    mse_fuzzy2(i) = mean(mse_fuzzy2_data.^2);
end

% Debug
disp('MSE PID:');
disp(mse_pid2);
disp('MSE Fuzzy:');
disp(mse_fuzzy2);

% Plot dos resultados com escala logarítmica no eixo y
figure;
semilogy(sine_amplitudes, mse_pid2, '-o', 'DisplayName', 'PID Controller');
hold on;
semilogy(sine_amplitudes, mse_fuzzy2, '-x', 'DisplayName', 'Fuzzy Logic Controller');
xlabel('Sine Wave Amplitude');
ylabel('MSE (log scale)');
title('MSE Comparison for Different Sine Wave Amplitudes');
legend('show');
grid on;
