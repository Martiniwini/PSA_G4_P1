load ('step_100.mat')
Wreal = step_100.Y(3).Data
t = step_100.X.Data
plot(t,Wreal)
xlim([7.5,8.7])