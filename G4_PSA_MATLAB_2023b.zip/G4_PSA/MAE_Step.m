% Definir valores de step para testar
step_values = [20, 40, 60, 80];
num_values = length(step_values);

mae_pid = zeros(1, num_values);
mae_fuzzy = zeros(1, num_values);

for i = 1:num_values
    set_param('MAE_Sim_Step/Step4', 'After', num2str(step_values(i)));
    
    simOut = sim('MAE_Sim_Step');
    
    % Extrair os resultados do MAE da simulação e calcular o erro médio absoluto
    mae_pid_data = simOut.get('mae_pid');
    mae_fuzzy_data = simOut.get('mae_fuzzy');
    
    % Debug
    disp('mae_pid_data:');
    disp(mae_pid_data);
    disp('mae_fuzzy_data:');
    disp(mae_fuzzy_data);
    
    % Retirar valores NaN
    mae_pid_data = mae_pid_data(~isnan(mae_pid_data));
    mae_fuzzy_data = mae_fuzzy_data(~isnan(mae_fuzzy_data));
    
    % Calcular o erro médio absoluto para PID e Fuzzy
    mae_pid(i) = mean(abs(mae_pid_data));   
    mae_fuzzy(i) = mean(abs(mae_fuzzy_data));
end

% Debug
disp('MAE PID:');
disp(mae_pid);
disp('MAE Fuzzy:');
disp(mae_fuzzy);

% Plot dos resultados
figure;
plot(step_values, mae_pid, '-o', 'DisplayName', 'PID Controller');
hold on;
plot(step_values, mae_fuzzy, '-x', 'DisplayName', 'Fuzzy Logic Controller');
xlabel('Step Value');
ylabel('MAE');
title('MAE Comparison for Different Step Values');
legend('show');
grid on;
