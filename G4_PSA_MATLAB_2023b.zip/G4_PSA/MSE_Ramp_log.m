% Definir valores de slopes para testar
ramp_slopes = [1, 2, 3, 4];
num_values = length(ramp_slopes);

mse_pid1 = zeros(1, num_values);
mse_fuzzy1 = zeros(1, num_values);

for i = 1:num_values
    set_param('MSE_Sim_Ramp/Ramp2', 'Slope', num2str(ramp_slopes(i)));
    
    simOut = sim('MSE_Sim_Ramp');
    
    % Extrair os resultados do MSE da simulação e calcular o erro quadrático médio
    mse_pid1_data = simOut.get('mse_pid1');
    mse_fuzzy1_data = simOut.get('mse_fuzzy1');
    
    % Debug
    disp('mse_pid1_data:');
    disp(mse_pid1_data);
    disp('mse_fuzzy1_data:');
    disp(mse_fuzzy1_data);
    
    % Retirar valores NaN
    mse_pid1_data = mse_pid1_data(~isnan(mse_pid1_data));
    mse_fuzzy1_data = mse_fuzzy1_data(~isnan(mse_fuzzy1_data));
    
    % Calcular o erro quadrático médio para PID e Fuzzy
    mse_pid1(i) = mean(mse_pid1_data.^2);   
    mse_fuzzy1(i) = mean(mse_fuzzy1_data.^2);
end

% Debug
disp('MSE PID:');
disp(mse_pid1);
disp('MSE Fuzzy:');
disp(mse_fuzzy1);

% Plot dos resultados com escala logarítmica no eixo y
figure;
semilogy(ramp_slopes, mse_pid1, '-o', 'DisplayName', 'PID Controller');
hold on;
semilogy(ramp_slopes, mse_fuzzy1, '-x', 'DisplayName', 'Fuzzy Logic Controller');
xlabel('Ramp Slope');
ylabel('MSE (log scale)');
title('MSE Comparison for Different Ramp Slopes');
legend('show');
grid on;
