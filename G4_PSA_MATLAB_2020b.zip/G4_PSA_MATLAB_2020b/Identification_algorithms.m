% clear all
close all
clc
s = tf('s');

%% Abrir dados

load ('step_100.mat')
Vel_real_total = step_100.Y(3).Data;
t_total = step_100.X.Data;
u_total = step_100.Y(1).Data/3.992; 

figure(1)
plot(t_total,Vel_real_total)
hold on
plot(t_total,u_total)

t_i = t_total (74000);
t_j = t_total (90000);

t = [];
Vel_real = [];
u = [];
for i=1:length(t_total)
    if (t_total(i) >= t_i & t_total (i) <= t_j)
        t = [t t_total(i)];
        Vel_real = [Vel_real Vel_real_total(i)];
        u = [u u_total(i)];
    end
end

figure(2)
plot(t,Vel_real)
hold on
plot (t,u)
    
%% Identificação da planta - optimização local

global  t Vel_real u;

parameters(1) = 20; %polo1
parameters(2) = 20; %polo2
parameters(3) = 1; %ganho

options = optimset('Display','iter', 'MaxIter', 2^16,'TolFun',1e-6, 'TolX',1e-6,'MaxFunEvals',2^16);
[poles,MSE] = fminsearch(@F_minimizacao, parameters, options);

%% simulação optimização local
p1 = poles(1);
p2 = poles(2);
K = poles(3); 

TF = K/((s+p1)*(s+p2));
Vel_opt = lsim(TF,u,t);

figure (3)
plot(t, Vel_real)
hold on
plot(t,Vel_opt)
%%
TF = K/((s+p1)*(s+p2));
TF_pos = K/((s+p1)*(s+p2)*s);
figure (4)
rlocus(TF_pos)
TF_control = feedback(40*TF_pos,1);
step(100*TF_control,0.5)
figure(5)
rlocus(TF_pos)

%% Pendulo 1
m=0.214;
J=0.0051;
C=0.0026;
l=0.275;
g=9.81;
Jeq = J + (m*l^2);

G_a = (K/((s+p1)*(s+p2)))*((m*l*s^2)/((Jeq*s^2)+(C*s)-(m*g*l)))*(1/s);
teta=((m*l*s^2)/((Jeq*s^2)+(C*s)-(m*g*l)));
figure(11)
rlocus(teta)
figure(12)
rlocus(G_a)

zc1_a=10;
zc2_a=15;
k1_a = 1.5;
Gc_a = (k1_a*(s+zc1_a)*(s+zc2_a)/s);
figure(13)
rlocus(G_a*Gc_a)

Kd=1.5;%K3
Kp=37.5;%K1
Ki=225;%k2
Ti=Ki/Kp; %/Ki;
Td=Kd/Kp;

%% Pendulo 2
m=0.214;
J=0.0051;
C=0.0026;
l=0.275;
g=9.81;
Jeq = J + (m*l^2);

G1 = (K/((s+p1)*(s+p2)))*((m*l*s^2)/((Jeq*s^2)+(C*s)-(m*g*l)))*(1/s);
teta=((m*l*s^2)/((Jeq*s^2)+(C*s)-(m*g*l)));
% figure(11)
% rlocus(teta)
% figure(12)
% rlocus(G1)

zc1=10;
zc2=8.75;
s1=-11.5 + 1.5i;
G = (K/((s1+p1)*(s1+p2)))*((m*l*s1^2)/((Jeq*s1^2)+(C*s1)-(m*g*l)))*(1/s1);
Gc = ((s1+zc1)*(s1+zc2)/s1);
k1= 1/(abs(Gc*G));
% k1 = 1.5;
Gc_novo = (k1*(s+zc1)*(s+zc2)/s);
figure(14)
rlocus(G1*Gc_novo)

Kd1=4.508;%K3
Kp1=84.52;%K1
Ki1=394.4;%k2
Ti1=Ki1/Kp1;% /Ki1;
Td1=Kd1/Kp1;
