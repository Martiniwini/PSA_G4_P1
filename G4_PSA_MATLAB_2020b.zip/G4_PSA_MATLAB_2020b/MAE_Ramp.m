% Definir valores de slopes para testar
ramp_slopes = [1, 2, 3, 4];
num_values = length(ramp_slopes);

mae_pid1 = zeros(1, num_values);
mae_fuzzy1 = zeros(1, num_values);

for i = 1:num_values
    set_param('MAE_Sim_Ramp/Ramp3', 'Slope', num2str(ramp_slopes(i)));
    
    simOut = sim('MAE_Sim_Ramp'); %trocar?
    
    % Extrair os resultados do MAE da simulação e calcular o erro médio absoluto
    mae_pid1_data = simOut.get('mae_pid1');
    mae_fuzzy1_data = simOut.get('mae_fuzzy1');
    
    % Debug
    disp('mae_pid1_data:');
    disp(mae_pid1_data);
    disp('mae_fuzzy1_data:');
    disp(mae_fuzzy1_data);
    
    % Retirar valores NaN
    mae_pid1_data = mae_pid1_data(~isnan(mae_pid1_data));
    mae_fuzzy1_data = mae_fuzzy1_data(~isnan(mae_fuzzy1_data));
    
    % Calcular o erro médio absoluto para PID e Fuzzy
    mae_pid1(i) = mean(abs(mae_pid1_data));   
    mae_fuzzy1(i) = mean(abs(mae_fuzzy1_data));
end

% Debug
disp('MAE PID:');
disp(mae_pid1);
disp('MAE Fuzzy:');
disp(mae_fuzzy1);

% Plot dos resultados
figure;
plot(ramp_slopes, mae_pid1, '-o', 'DisplayName', 'PID Controller');
hold on;
plot(ramp_slopes, mae_fuzzy1, '-x', 'DisplayName', 'Fuzzy Logic Controller');
xlabel('Ramp Slope');
ylabel('MAE');
title('MAE Comparison for Different Ramp Slopes');
legend('show');
grid on;
