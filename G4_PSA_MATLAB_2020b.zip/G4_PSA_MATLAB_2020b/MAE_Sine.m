% Definir valores de amplitude para testar
sine_amplitudes = [20, 80, 140, 200];
num_values = length(sine_amplitudes);

mae_pid2 = zeros(1, num_values);
mae_fuzzy2 = zeros(1, num_values);

for i = 1:num_values
    set_param('MAE_Sim_Sine/Sine Wave5', 'Amplitude', num2str(sine_amplitudes(i)));
    
    simOut = sim('MAE_Sim_Sine');
    
    % Extrair os resultados do MAE da simulação e calcular o erro médio absoluto
    mae_pid2_data = simOut.get('mae_pid2');
    mae_fuzzy2_data = simOut.get('mae_fuzzy2');
    
    % Debug
    disp('mae_pid2_data:');
    disp(mae_pid2_data);
    disp('mae_fuzzy2_data:');
    disp(mae_fuzzy2_data);
    
    % Retirar valores NaN
    mae_pid2_data = mae_pid2_data(~isnan(mae_pid2_data));
    mae_fuzzy2_data = mae_fuzzy2_data(~isnan(mae_fuzzy2_data));
    
    % Calcular o erro médio absoluto para PID e Fuzzy
    mae_pid2(i) = mean(abs(mae_pid2_data));   
    mae_fuzzy2(i) = mean(abs(mae_fuzzy2_data));
end

% Debug
disp('MAE PID:');
disp(mae_pid2);
disp('MAE Fuzzy:');
disp(mae_fuzzy2);

% Plot dos resultados
figure;
plot(sine_amplitudes, mae_pid2, '-o', 'DisplayName', 'PID Controller');
hold on;
plot(sine_amplitudes, mae_fuzzy2, '-x', 'DisplayName', 'Fuzzy Logic Controller');
xlabel('Sine Wave Amplitude');
ylabel('MAE');
title('MAE Comparison for Different Sine Wave Amplitudes');
legend('show');
grid on;
