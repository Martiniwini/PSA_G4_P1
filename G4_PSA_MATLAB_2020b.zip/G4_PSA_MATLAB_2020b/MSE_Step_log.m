% Definir valores de step para testar
step_values = [20, 40, 60, 80];
num_values = length(step_values);

mse_pid = zeros(1, num_values);
mse_fuzzy = zeros(1, num_values);

for i = 1:num_values
    set_param('MSE_Sim_Step/Step3', 'After', num2str(step_values(i)));
    
    simOut = sim('MSE_Sim_Step');
    
    % Extrair os resultados do MSE da simulação e calcular o erro quadrático médio
    mse_pid_data = simOut.get('mse_pid');
    mse_fuzzy_data = simOut.get('mse_fuzzy');
    
    % Debug
    disp('mse_pid_data:');
    disp(mse_pid_data);
    disp('mse_fuzzy_data:');
    disp(mse_fuzzy_data);
    
    % Retirar valores NaN
    mse_pid_data = mse_pid_data(~isnan(mse_pid_data));
    mse_fuzzy_data = mse_fuzzy_data(~isnan(mse_fuzzy_data));
    
    % Calcular o erro quadrático médio para PID e Fuzzy
    mse_pid(i) = mean(mse_pid_data.^2);   
    mse_fuzzy(i) = mean(mse_fuzzy_data.^2);
end

% Debug
disp('MSE PID:');
disp(mse_pid);
disp('MSE Fuzzy:');
disp(mse_fuzzy);

% Plot dos resultados com escala logarítmica no eixo y
figure;
semilogy(step_values, mse_pid, '-o', 'DisplayName', 'PID Controller');
hold on;
semilogy(step_values, mse_fuzzy, '-x', 'DisplayName', 'Fuzzy Logic Controller');
xlabel('Step Value');
ylabel('MSE (log scale)');
title('MSE Comparison for Different Step Values');
legend('show');
grid on;
