
function mse = F_minimizacao(Parameters)

global t Vel_real u; 

p1 = Parameters(1);
p2 = Parameters(2);
K = Parameters(3);

s = tf('s');
TF = K/((s+p1)*(s+p2));


Vel_sim = lsim(TF,u,t);

erro = Vel_real' - Vel_sim;
mse = mean((erro).^2);

